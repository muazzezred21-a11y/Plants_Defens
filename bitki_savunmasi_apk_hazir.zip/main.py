
# ============================================================
# BİTKİ SAVUNMASI - ANDROID KIVY SÜRÜMÜ
# OPTİMİZE EDİLMİŞ SÜRÜM
# ============================================================

from kivy.config import Config
Config.set("graphics", "orientation", "landscape")
Config.set("graphics", "fullscreen", "auto")
Config.set("graphics", "resizable", "1")

import os
import math
import random
import wave
import struct
import tempfile
from collections import OrderedDict

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.core.text import Label as CoreLabel
from kivy.graphics import (
    Color, Rectangle, Ellipse, Line,
    RoundedRectangle, PushMatrix, PopMatrix,
    Translate, Scale, Fbo, ClearColor, ClearBuffers
)
from kivy.uix.widget import Widget

# =====================================================
# EKRAN AYARLARI
# =====================================================

W, H = 960, 540
ROWS, COLS = 5, 9
GX, GY = 105, 115
CW, CH = 82, 78
MAX_DECK = 5

Window.clearcolor = (0.05, 0.1, 0.05, 1)
Window.fullscreen = "auto"

TRANSLATIONS = {
    "Sunflower": "Ayçiçeği",
    "Peashooter": "Bezelye Atıcı",
    "Wallnut": "Ceviz",
    "Icepea": "Buz Bezelyesi",
    "Repeater": "Çift Bezelye",
    "Cherry": "Kiraz Bombası",
    "Bomb": "Patates Mayını",
    "Cabbagepult": "Lahana Atıcı",
    "SnowPea": "Kar Bezelyesi",
    "Spikeweed": "Dikenli Ot",
    "Garlic": "Sarımsak",
    "Torchwood": "Ateş Kütüğü",
    "GatlingPea": "Makineli Bezelye",
    "Tallnut": "Büyük Ceviz",
    "Melonpult": "Karpuz Atıcı",
    "ElectricPea": "Elektrik Bezelyesi",
    "LaserFlower": "Lazer Çiçeği",
    "FirePea": "Ateş Bezelyesi",
    "Mushroom": "Mantar",
    "GoldSunflower": "Altın Ayçiçeği"
}

PLANTS = {
    "Sunflower": [50, 120, (255, 190, 35), "sun", 7, 0],
    "Peashooter": [100, 130, (75, 205, 55), "shoot", 1.35, 25],
    "Wallnut": [50, 850, (165, 105, 55), "wall", 0, 0],
    "Icepea": [175, 130, (90, 205, 255), "ice", 1.7, 25],
    "Repeater": [200, 140, (65, 190, 45), "double", .85, 22],
    "Cherry": [150, 100, (235, 55, 65), "boom", 0, 350],
    "Bomb": [25, 100, (190, 155, 75), "mine", 0, 220],
    "Cabbagepult": [100, 130, (100, 180, 65), "lob", 1.8, 45],
    "SnowPea": [175, 130, (110, 215, 255), "slow", 1.5, 28],
    "Spikeweed": [100, 270, (100, 150, 55), "spike", .8, 25],
    "Garlic": [75, 250, (245, 235, 200), "garlic", 0, 0],
    "Torchwood": [175, 320, (225, 100, 35), "torch", 0, 0],
    "GatlingPea": [300, 150, (45, 165, 45), "gatling", .32, 20],
    "Tallnut": [125, 1600, (145, 95, 50), "wall", 0, 0],
    "Melonpult": [250, 150, (60, 180, 75), "melon", 2.3, 80],
    "ElectricPea": [275, 140, (160, 100, 255), "electric", 1.4, 35],
    "LaserFlower": [225, 125, (255, 90, 180), "laser", 1.1, 40],
    "FirePea": [200, 140, (255, 125, 40), "fire", 1.3, 35],
    "Mushroom": [75, 100, (175, 90, 200), "mushroom", 1.5, 30],
    "GoldSunflower": [150, 140, (255, 220, 65), "gold", 5, 0],
}

ALL_PLANTS = list(PLANTS.keys())

ZOMBIES = {
    "normal": [100, 17],
    "cone": [230, 15],
    "bucket": [450, 11],
    "runner": [85, 29],
    "giant": [850, 8],
    "doctor": [300, 13],
    "ninja": [160, 25],
}


# =====================================================
# SES DOSYASI ÜRETİMİ
# =====================================================

def create_wav(path, notes, volume=0.22):
    rate = 22050

    with wave.open(path, "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(rate)

        for freq, duration in notes:
            count = int(rate * duration)
            samples = bytearray()

            for i in range(count):
                t = i / rate
                fade = min(1, i / max(1, count * .08))
                fade *= min(1, (count - i) / max(1, count * .12))

                value = math.sin(2 * math.pi * freq * t)
                value += .2 * math.sin(2 * math.pi * freq * 2 * t)

                sample = int(
                    max(-1, min(1, value * fade)) *
                    volume * 30000
                )

                samples.extend(struct.pack("<h", sample))

            f.writeframes(samples)


# =====================================================
# ANA OYUN
# =====================================================

class PlantDefense(Widget):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.state = "menu"
        self.sound_on = True
        self.sounds = {}
        self.music = None
        self.sound_dir = tempfile.mkdtemp(prefix="plantdefense_")

        # OPTİMİZASYON: Yazı önbelleği
        self.text_cache = OrderedDict()
        self.text_cache_limit = 700

        # OPTİMİZASYON: Arka plan FBO önbelleği
        self.background_fbo = None
        self.background_texture = None
        self.background_cache_ready = False

        # OPTİMİZASYON: Arka plan süsleri bir kez oluşturulur.
        rng = random.Random(12)
        self.background_speckles = []

        for _ in range(350):
            self.background_speckles.append((
                rng.randint(90, 855),
                rng.randint(110, 505),
                rng.choice([
                    (65, 145, 40),
                    (90, 170, 50),
                    (100, 180, 60),
                    (70, 155, 45)
                ]),
                rng.randint(1, 2)
            ))

        self.make_audio()

        self.deck = [
            "Sunflower", "Peashooter", "Wallnut",
            "Icepea", "Repeater"
        ]

        self.deck_page = 0
        self.unlocked_plant_count = 5
        self.newly_unlocked_plant = None

        self.current_level = 1
        self.unlocked_level = 1

        self.plants = []
        self.zombies = []
        self.bullets = []
        self.suns = []
        self.particles = []

        self.sun = 250
        self.score = 0
        self.level_kills = 0
        self.level_goal = 12

        self.selected = None
        self.spawn_timer = 2
        self.sun_timer = 5
        self.game_time = 0

        self.boss = None
        self.boss_spawned = False

        self.paused_from = "game"

        self.scale = 1
        self.off_x = 0
        self.off_y = 0

        self.bind(size=self.redraw, pos=self.redraw)

        # FBO, grafik bağlamı hazır olduğunda oluşturulur.
        Clock.schedule_once(self.build_background_cache, 0)

        Clock.schedule_interval(self.update, 1 / 60)

        Clock.schedule_once(self.initial_redraw, 0)

    def initial_redraw(self, dt):
        self.redraw()

    # =================================================
    # OPTİMİZE ARKA PLAN ÖNBELLEĞİ
    # =================================================

    def build_background_cache(self, dt=0):
        try:
            fbo = Fbo(
                size=(W, H),
                with_stencilbuffer=True
            )

            with fbo:
                ClearColor(0, 0, 0, 0)
                ClearBuffers()
                self.draw_background()

            fbo.draw()

            # FBO zaten Kivy'nin beklediği yönde çiziliyor.
            # Dikey çevirmek gökyüzünü alta, çimleri üste taşıyordu.
            texture = fbo.texture

            self.background_fbo = fbo
            self.background_texture = texture
            self.background_cache_ready = texture is not None

        except Exception:
            self.background_fbo = None
            self.background_texture = None
            self.background_cache_ready = False

        self.redraw()

    def draw_cached_background(self):
        if self.background_cache_ready and self.background_texture:
            Color(1, 1, 1, 1)

            Rectangle(
                texture=self.background_texture,
                pos=(0, 0),
                size=(W, H)
            )
        else:
            self.draw_background()

    # =================================================
    # ANDROID YATAY EKRAN
    # =================================================

    def force_landscape(self):
        try:
            from jnius import autoclass

            PythonActivity = autoclass(
                "org.kivy.android.PythonActivity"
            )
            ActivityInfo = autoclass(
                "android.content.pm.ActivityInfo"
            )

            activity = PythonActivity.mActivity

            activity.setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            )

            View = autoclass("android.view.View")

            flags = (
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            )

            activity.getWindow().getDecorView().setSystemUiVisibility(
                flags
            )

        except Exception:
            pass

    # =================================================
    # SES
    # =================================================

    def make_audio(self):
        try:
            from kivy.core.audio import SoundLoader

            definitions = {
                "click": [(650, .04)],
                "plant": [(330, .06), (480, .08)],
                "sun": [(900, .05), (1250, .12)],
                "shoot": [(750, .035)],
                "ice": [(1200, .05), (1600, .07)],
                "hit": [(180, .07), (110, .05)],
                "explosion": [(100, .18), (65, .22)],
                "boss": [(100, .2), (80, .25), (60, .35)],
                "boss_hit": [(250, .05), (130, .09)],
                "win": [(500, .1), (700, .1), (1000, .2)],
                "lose": [(250, .15), (170, .2), (100, .3)]
            }

            for name, notes in definitions.items():
                path = os.path.join(
                    self.sound_dir,
                    name + ".wav"
                )

                create_wav(path, notes)
                snd = SoundLoader.load(path)

                if snd:
                    self.sounds[name] = snd

            melody = [
                523, 659, 784, 659, 587, 698, 880, 698,
                523, 659, 784, 988, 880, 784, 659, 587,
                659, 784, 880, 784, 698, 880, 988, 880,
                784, 698, 659, 587, 523, 587, 659, 523
            ]

            path = os.path.join(self.sound_dir, "music.wav")
            create_wav(
                path,
                [(n, .22) for n in melody],
                .12
            )

            self.music = SoundLoader.load(path)

            if self.music:
                self.music.loop = True
                self.music.volume = .28
                self.music.play()

        except Exception:
            self.sounds = {}
            self.music = None

    def play(self, name):
        if not self.sound_on:
            return

        snd = self.sounds.get(name)

        if snd:
            try:
                snd.stop()
                snd.play()
            except Exception:
                pass

    # =================================================
    # ÇİZİM YARDIMCILARI
    # =================================================

    def color(self, c, a=1):
        Color(
            c[0] / 255,
            c[1] / 255,
            c[2] / 255,
            a
        )

    def rect(self, x, y, w, h, c, radius=0, border=None):
        self.color(c)
        pos = (x, H - y - h)

        if radius:
            RoundedRectangle(
                pos=pos,
                size=(w, h),
                radius=[radius]
            )
        else:
            Rectangle(pos=pos, size=(w, h))

        if border:
            self.color(border)
            Line(
                rounded_rectangle=(
                    x, H-y-h, w, h, radius
                ),
                width=1.5
            )

    def circle(self, x, y, r, c):
        self.color(c)
        Ellipse(
            pos=(x-r, H-y-r),
            size=(r*2, r*2)
        )

    def line(self, x1, y1, x2, y2, c, width=2):
        self.color(c)
        Line(
            points=[x1, H-y1, x2, H-y2],
            width=width
        )

    def polygon(self, points, c):
        self.color(c)
        pts = []

        for x, y in points:
            pts.extend([x, H-y])

        Line(
            points=pts + pts[:2],
            width=2
        )

    # =================================================
    # OPTİMİZE YAZI ÇİZİMİ
    # =====================================================

    def text(self, value, x, y, size=20, color=(255, 255, 255)):
        value = str(value)
        key = (value, size, color)

        texture = self.text_cache.get(key)

        if texture is None:
            label = CoreLabel(
                text=value,
                font_size=size,
                bold=True,
                color=(
                    color[0]/255,
                    color[1]/255,
                    color[2]/255,
                    1
                )
            )

            label.refresh()
            texture = label.texture

            self.text_cache[key] = texture

            # Bellek kullanımını sınırlı tut.
            if len(self.text_cache) > self.text_cache_limit:
                self.text_cache.popitem(last=False)

        else:
            self.text_cache.move_to_end(key)

        tw, th = texture.size

        Color(1, 1, 1, 1)

        Rectangle(
            texture=texture,
            pos=(x-tw/2, H-y-th/2),
            size=texture.size
        )

    def button(self, title, x, y, w, h, color=(55, 140, 45)):
        self.rect(
            x, y, w, h,
            color,
            10,
            (230, 190, 85)
        )

        self.text(
            title,
            x+w/2,
            y+h/2,
            18
        )

    def glow(self, x, y, radius, c):
        for i in range(3):
            self.color(c, .08+i*.04)
            r = radius*(1+i*.5)

            Ellipse(
                pos=(x-r, H-y-r),
                size=(r*2, r*2)
            )

    # =================================================
    # ARKA PLAN
    # =================================================

    def draw_background(self):
        self.rect(0, 0, W, H, (105, 180, 235))

        self.circle(850, 55, 28, (255, 225, 95))

        for x, y in [
            (150, 45),
            (420, 25),
            (700, 50)
        ]:
            self.circle(x, y, 20, (255, 255, 255))
            self.circle(x+22, y-7, 25, (255, 255, 255))
            self.circle(x+45, y, 19, (255, 255, 255))

        self.rect(0, 105, W, 435, (75, 155, 55))
        self.rect(85, 105, 775, 405, (75, 155, 45))

        # OPTİMİZASYON: Rastgele noktalar önceden hesaplanıyor.
        for x, y, c, radius in self.background_speckles:
            self.circle(x, y, radius, c)

        for r in range(ROWS):
            for c in range(COLS):
                x = GX+c*CW
                y = GY+r*CH

                col = (
                    (95, 175, 65)
                    if (r+c) % 2
                    else (80, 155, 55)
                )

                self.rect(x, y, CW-2, CH-2, col, 7)
                self.rect(
                    x+2, y+2,
                    CW-6, CH-6,
                    (105, 185, 75),
                    5
                )

        self.rect(8, 260, 85, 190, (180, 105, 55))
        self.polygon(
            [(0, 260), (50, 205), (100, 260)],
            (145, 55, 40)
        )
        self.rect(35, 355, 32, 95, (100, 55, 35))
        self.circle(59, 400, 3, (255, 210, 65))
        self.rect(15, 290, 24, 32, (125, 195, 225))
        self.rect(65, 290, 20, 32, (125, 195, 225))

    # =================================================
    # BİTKİ ÇİZİMİ
    # =================================================

    def draw_plant(self, p):
        name = p["name"]
        x, y = p["x"], p["y"]
        t = p["anim"]

        bob = math.sin(t*3)*2
        yy = y+bob
        col = PLANTS[name][2]

        self.color((35, 85, 35))
        Ellipse(
            pos=(x-27, H-(y+30)-12),
            size=(54, 12)
        )

        if name not in ("Wallnut", "Tallnut", "Bomb"):
            self.line(
                x, yy+20,
                x-10, yy+28,
                (35, 120, 35), 5
            )
            self.circle(x-15, yy+23, 9, (45, 145, 40))
            self.circle(x+15, yy+23, 9, (55, 160, 45))

        if name in ("Sunflower", "GoldSunflower"):
            for i in range(16):
                a = i*math.tau/16+t*.25
                px = x+math.cos(a)*20
                py = yy+math.sin(a)*20
                self.circle(px, py, 7, (255, 205, 40))

            self.circle(x, yy, 16, (140, 80, 30))
            self.circle(x, yy, 12, (230, 155, 40))
            self.circle(x-6, yy-5, 4, (255, 255, 255))
            self.circle(x+7, yy-5, 4, (255, 255, 255))
            self.circle(x-5, yy-5, 2, (20, 20, 20))
            self.circle(x+8, yy-5, 2, (20, 20, 20))

        elif name in (
            "Peashooter", "Icepea", "Repeater",
            "SnowPea", "GatlingPea", "ElectricPea",
            "FirePea"
        ):
            self.circle(x-3, yy-5, 23, col)
            self.circle(x+17, yy-4, 14, col)
            self.circle(x+24, yy-4, 7, (25, 65, 25))
            self.circle(x-10, yy-14, 7, (255, 255, 255))
            self.circle(x+4, yy-15, 6, (255, 255, 255))
            self.circle(x-9, yy-14, 3, (15, 15, 15))
            self.circle(x+5, yy-15, 3, (15, 15, 15))

            if name in ("Repeater", "GatlingPea"):
                self.circle(x+12, yy+10, 10, col)

            if name == "ElectricPea":
                self.glow(x+22, yy-5, 15, (170, 90, 255))

            if name == "FirePea":
                self.glow(x+22, yy-5, 15, (255, 100, 20))

        elif name in ("Wallnut", "Tallnut"):
            self.circle(x, yy, 25, (105, 65, 30))
            self.circle(x, yy-2, 21, (175, 115, 55))
            self.circle(x-8, yy-8, 6, (255, 255, 255))
            self.circle(x+9, yy-8, 6, (255, 255, 255))
            self.circle(x-7, yy-8, 2, (15, 15, 15))
            self.circle(x+10, yy-8, 2, (15, 15, 15))

        elif name == "Cherry":
            self.line(
                x, yy-15,
                x+7, yy-35,
                (35, 120, 35), 4
            )
            self.circle(x-12, yy, 18, (180, 20, 35))
            self.circle(x+13, yy+2, 18, (230, 35, 50))
            self.circle(x-17, yy-7, 5, (255, 120, 100))
            self.circle(x+8, yy-5, 5, (255, 120, 100))

        elif name == "Spikeweed":
            for i in range(9):
                px = x-25+i*6
                self.polygon(
                    [
                        (px-5, yy+16),
                        (px+2, yy-20),
                        (px+8, yy+16)
                    ],
                    (100, 160, 50)
                )

        elif name == "Garlic":
            self.circle(x, yy, 21, (235, 230, 200))
            self.circle(x-7, yy-4, 4, (255, 255, 255))
            self.circle(x+8, yy-4, 4, (255, 255, 255))

        elif name == "Torchwood":
            self.rect(
                x-14, yy-10,
                28, 42,
                (110, 60, 30), 6
            )
            self.glow(x, yy-25, 20, (255, 100, 20))
            self.polygon(
                [
                    (x-15, yy-8),
                    (x, yy-42),
                    (x+15, yy-8)
                ],
                (255, 145, 30)
            )

        elif name == "Mushroom":
            self.rect(
                x-7, yy-3,
                14, 30,
                (225, 210, 190), 5
            )
            self.circle(x, yy-15, 23, (160, 75, 190))
            self.circle(x-9, yy-16, 5, (255, 255, 255))
            self.circle(x+9, yy-16, 5, (255, 255, 255))

        else:
            self.circle(x, yy, 20, col)
            self.circle(x-7, yy-5, 5, (255, 255, 255))

        ratio = max(
            0,
            p["health"]/PLANTS[name][1]
        )

        self.rect(x-22, y+37, 44, 5, (65, 20, 20))
        self.rect(
            x-22, y+37,
            44*ratio, 5,
            (50, 220, 65)
        )

    def draw_plant_icon(self, name, x, y):
        self.draw_plant({
            "name": name,
            "x": x,
            "y": y,
            "anim": 0,
            "health": PLANTS[name][1],
            "recoil": 0,
            "hit": 0
        })

    # =================================================
    # ZOMBİ ÇİZİMİ
    # =================================================

    def draw_zombie(self, z):
        x, y = z["x"], z["y"]
        t = z["anim"]

        step = math.sin(t*9)*6
        arm = math.sin(t*8)*10

        body = (125, 160, 110)

        if z["flash"] > 0:
            body = (220, 245, 210)

        self.circle(x, y+20, 22, (55, 75, 45))

        self.line(
            x-8, y+12,
            x-13+step, y+36,
            (45, 65, 50), 9
        )

        self.line(
            x+8, y+12,
            x+13-step, y+36,
            (45, 65, 50), 9
        )

        self.rect(x-17, y-4, 34, 35, (105, 75, 65), 5)

        self.line(
            x-13, y+3,
            x-29, y+18+arm,
            body, 8
        )

        self.line(
            x+13, y+3,
            x+29, y+18-arm,
            body, 8
        )

        self.circle(x, y-18, 20, body)
        self.circle(x-9, y-23, 7, (255, 255, 255))
        self.circle(x+8, y-23, 7, (255, 255, 255))
        self.circle(x-8, y-22, 3, (20, 20, 20))
        self.circle(x+9, y-22, 3, (20, 20, 20))
        self.rect(x-9, y-7, 18, 7, (65, 30, 30), 3)

        if z["type"] == "cone":
            self.polygon(
                [
                    (x-19, y-32),
                    (x+19, y-32),
                    (x, y-70)
                ],
                (220, 100, 20)
            )

        elif z["type"] == "bucket":
            self.rect(
                x-21, y-53,
                42, 25,
                (150, 165, 170), 5
            )

        elif z["type"] == "ninja":
            self.rect(
                x-20, y-35,
                40, 17,
                (30, 40, 55)
            )

        elif z["type"] == "doctor":
            self.rect(
                x-20, y-43,
                40, 12,
                (255, 255, 255)
            )
            self.line(
                x, y-40,
                x, y-32,
                (210, 40, 40), 3
            )

        elif z["type"] == "giant":
            self.rect(
                x-27, y-53,
                54, 23,
                (140, 105, 75), 5
            )

        ratio = max(0, z["health"]/z["max"])

        self.rect(x-20, y-78, 40, 5, (70, 20, 20))
        self.rect(
            x-20, y-78,
            40*ratio, 5,
            (70, 220, 65)
        )

    # =================================================
    # PATRON
    # =================================================

    def spawn_boss(self):
        hp = 1800+self.current_level*180

        self.boss = {
            "x": 900,
            "y": GY+2*CH+CH//2,
            "health": hp,
            "max": hp,
            "speed": 7+self.current_level*.12,
            "attack": 0,
            "anim": 0,
            "type": self.current_level//5,
            "flash": 0
        }

        self.play("boss")

    def draw_boss(self):
        b = self.boss

        if not b:
            return

        x, y = b["x"], b["y"]
        bob = math.sin(b["anim"]*3)*4

        col = (
            (220, 245, 200)
            if b["flash"] > 0
            else (110, 145, 90)
        )

        self.circle(x, y+25, 45, (30, 65, 30))
        self.circle(x, y+bob, 42, col)

        self.line(
            x-30, y-5,
            x-55, y+25,
            (85, 125, 75), 16
        )

        self.line(
            x+30, y-5,
            x+55, y+25,
            (85, 125, 75), 16
        )

        self.circle(x, y-48+bob, 35, col)
        self.circle(x-15, y-49+bob, 11, (255, 255, 255))
        self.circle(x+15, y-49+bob, 11, (255, 255, 255))
        self.circle(x-13, y-49+bob, 5, (20, 20, 20))
        self.circle(x+17, y-49+bob, 5, (20, 20, 20))
        self.rect(x-16, y-25+bob, 32, 10, (60, 25, 25), 4)

        if b["type"] == 1:
            self.polygon(
                [
                    (x-35, y-65),
                    (x, y-110),
                    (x+35, y-65)
                ],
                (245, 100, 20)
            )

        elif b["type"] == 2:
            self.rect(
                x-38, y-85,
                76, 20,
                (160, 165, 175), 5
            )

        elif b["type"] == 3:
            self.circle(x, y-45+bob, 42, (170, 80, 220))

        elif b["type"] == 4:
            self.circle(x, y-45+bob, 45, (255, 80, 40))

        ratio = max(0, b["health"]/b["max"])

        self.rect(x-55, y-125, 110, 10, (70, 20, 20))
        self.rect(
            x-55, y-125,
            110*ratio, 10,
            (230, 45, 45)
        )

    # =================================================
    # GÜNEŞ VE PARÇACIKLAR
    # =================================================

    def particle(self, x, y, color, count=5):
        for _ in range(count):
            if len(self.particles) >= 220:
                break

            a = random.random()*math.tau
            speed = random.uniform(25, 150)

            self.particles.append({
                "x": x,
                "y": y,
                "vx": math.cos(a)*speed,
                "vy": math.sin(a)*speed,
                "life": random.uniform(.25, .7),
                "max": .7,
                "color": color,
                "size": random.randint(2, 6)
            })

    def burst(self, x, y, color, count=18):
        self.particle(x, y, color, count)
        self.particle(
            x, y,
            (255, 240, 150),
            count//2
        )

    def create_sun(self, x=None, y=None):
        if x is None:
            x = random.randint(140, 820)

        if y is None:
            y = -15

        self.suns.append({
            "x": x,
            "y": y,
            "target": random.randint(160, 470),
            "life": 12,
            "phase": random.random()*6
        })

    def draw_sun(self, s):
        x, y = s["x"], s["y"]
        pulse = math.sin(s["phase"]*4)*2

        self.glow(x, y, 15, (255, 205, 50))

        for i in range(12):
            a = i*math.pi/6+s["phase"]*.4

            self.line(
                x+math.cos(a)*13,
                y+math.sin(a)*13,
                x+math.cos(a)*19,
                y+math.sin(a)*19,
                (255, 220, 70),
                3
            )

        self.circle(x, y, 12+pulse, (255, 215, 65))
        self.circle(x-3, y-3, 5, (255, 245, 150))

    # =================================================
    # OYUN BAŞLATMA
    # =================================================

    def reset_game(self, level):
        self.plants = []
        self.zombies = []
        self.bullets = []
        self.suns = []
        self.particles = []

        self.sun = 250
        self.score = 0
        self.selected = None

        self.current_level = level
        self.level_kills = 0
        self.level_goal = 12+level*2

        self.boss_spawned = False
        self.boss = None

        self.spawn_timer = 2
        self.sun_timer = 5
        self.game_time = 0

        self.create_sun(350, 180)
        self.create_sun(600, 300)

        self.state = "game"

    def is_plant_unlocked(self, name):
        return ALL_PLANTS.index(name) < self.unlocked_plant_count

    # =================================================
    # ZOMBİ ÜRETME
    # =================================================

    def spawn_zombie(self):
        row = random.randrange(ROWS)

        if self.current_level < 3:
            kind = "normal"

        elif self.current_level < 6:
            kind = random.choice(["normal", "cone"])

        elif self.current_level < 10:
            kind = random.choice([
                "normal", "cone", "bucket", "runner"
            ])

        else:
            kind = random.choice(list(ZOMBIES.keys()))

        hp, speed = ZOMBIES[kind]

        hp *= 1+(self.current_level-1)*.085
        speed *= 1+(self.current_level-1)*.018

        self.zombies.append({
            "x": 890,
            "y": GY+row*CH+CH//2,
            "row": row,
            "health": hp,
            "max": hp,
            "speed": speed,
            "type": kind,
            "attack": 0,
            "anim": random.random()*5,
            "flash": 0,
            "knockback": 0
        })

    # =================================================
    # BİTKİ YERLEŞTİRME
    # =================================================

    def place_plant(self, mx, my):
        if self.selected is None:
            return

        col = int((mx-GX)//CW)
        row = int((my-GY)//CH)

        if not (0 <= col < COLS and 0 <= row < ROWS):
            return

        name = self.selected
        cost = PLANTS[name][0]

        if self.sun < cost:
            return

        if any(
            p["row"] == row and p["col"] == col
            for p in self.plants
        ):
            return

        self.sun -= cost

        self.plants.append({
            "name": name,
            "row": row,
            "col": col,
            "x": GX+col*CW+CW//2,
            "y": GY+row*CH+CH//2,
            "health": PLANTS[name][1],
            "timer": 0,
            "anim": random.random()*5,
            "recoil": 0,
            "hit": 0
        })

        self.play("plant")
        self.selected = None

    def damage_zombie(self, z, damage):
        z["health"] -= damage
        z["flash"] = .14
        z["knockback"] = 5

        self.particle(
            z["x"], z["y"],
            (170, 210, 130), 4
        )

        self.play("hit")

    # =================================================
    # OYUN GÜNCELLEME
    # =================================================

    def update_game(self, dt):
        self.game_time += dt
        self.sun_timer -= dt

        if self.sun_timer <= 0:
            self.create_sun()
            self.sun_timer = 7

        for s in self.suns[:]:
            s["phase"] += dt
            s["y"] = min(
                s["target"],
                s["y"]+45*dt
            )
            s["life"] -= dt

            if s["life"] <= 0:
                self.suns.remove(s)

        boss_level = self.current_level in (5, 10, 15, 20)

        if (
            boss_level
            and not self.boss_spawned
            and self.level_kills >= self.level_goal//2
        ):
            self.spawn_boss()
            self.boss_spawned = True

        self.spawn_timer -= dt

        if (
            self.spawn_timer <= 0
            and self.level_kills+len(self.zombies) < self.level_goal
        ):
            self.spawn_zombie()
            self.spawn_timer = max(
                1.2,
                5.5-self.current_level*.15
            )

        # Bitkiler
        for p in self.plants[:]:
            p["anim"] += dt
            p["timer"] -= dt
            p["recoil"] = max(0, p["recoil"]-dt*5)
            p["hit"] = max(0, p["hit"]-dt)

            name = p["name"]
            kind = PLANTS[name][3]

            if kind in ("sun", "gold"):
                if p["timer"] <= 0:
                    self.create_sun(p["x"], p["y"]-20)
                    p["timer"] = PLANTS[name][4]

            elif kind in (
                "shoot", "ice", "double", "lob",
                "slow", "gatling", "melon",
                "electric", "laser", "fire", "mushroom"
            ):
                enemy = any(
                    z["row"] == p["row"] and z["x"] > p["x"]
                    for z in self.zombies
                )

                if self.boss and abs(
                    self.boss["y"] -
                    (GY+p["row"]*CH+CH//2)
                ) < 40:
                    enemy = True

                if enemy and p["timer"] <= 0:
                    count = (
                        4 if kind == "gatling"
                        else 2 if kind == "double"
                        else 1
                    )

                    for _ in range(count):
                        self.bullets.append({
                            "x": p["x"]+20,
                            "y": p["y"]-5,
                            "row": p["row"],
                            "damage": PLANTS[name][5],
                            "speed": 390,
                            "kind": kind,
                            "life": 3,
                            "trail": []
                        })

                    p["recoil"] = 1
                    p["timer"] = PLANTS[name][4]

                    self.particle(
                        p["x"]+20,
                        p["y"]-5,
                        PLANTS[name][2],
                        3
                    )

                    self.play(
                        "ice"
                        if kind in ("ice", "slow")
                        else "shoot"
                    )

            elif kind == "boom":
                for z in self.zombies:
                    if (
                        abs(z["x"]-p["x"]) < 120
                        and abs(z["y"]-p["y"]) < 90
                    ):
                        z["health"] -= 350
                        z["flash"] = .3

                if (
                    self.boss
                    and abs(self.boss["x"]-p["x"]) < 140
                ):
                    self.boss["health"] -= 350
                    self.boss["flash"] = .3

                self.burst(
                    p["x"], p["y"],
                    (255, 100, 30), 35
                )

                self.play("explosion")
                self.plants.remove(p)

            elif kind == "mine":
                if p["timer"] <= -2:
                    for z in self.zombies:
                        if (
                            abs(z["x"]-p["x"]) < 75
                            and abs(z["y"]-p["y"]) < 55
                        ):
                            z["health"] -= 220
                            z["flash"] = .3

                    self.burst(
                        p["x"], p["y"],
                        (255, 160, 50), 22
                    )

                    self.plants.remove(p)
                    self.play("explosion")

            elif kind == "spike":
                for z in self.zombies:
                    if (
                        z["row"] == p["row"]
                        and abs(z["x"]-p["x"]) < 32
                        and p["timer"] <= 0
                    ):
                        z["health"] -= 25
                        z["flash"] = .1
                        p["timer"] = .8

            elif kind == "garlic":
                for z in self.zombies:
                    if (
                        z["row"] == p["row"]
                        and abs(z["x"]-p["x"]) < 30
                    ):
                        z["row"] = (
                            z["row"] +
                            random.choice([-1, 1])
                        ) % ROWS

                        z["y"] = (
                            GY+z["row"]*CH+CH//2
                        )

        # Mermiler
        for b in self.bullets[:]:
            b["trail"].append((b["x"], b["y"]))

            if len(b["trail"]) > 6:
                b["trail"].pop(0)

            b["x"] += b["speed"]*dt
            b["life"] -= dt

            if b["x"] > 900 or b["life"] <= 0:
                self.bullets.remove(b)
                continue

            hit = False

            for z in self.zombies:
                if (
                    z["row"] == b["row"]
                    and abs(z["x"]-b["x"]) < 24
                ):
                    damage = b["damage"]

                    if b["kind"] == "fire":
                        damage *= 1.7

                    if b["kind"] == "electric":
                        damage *= 1.5

                        for other in self.zombies:
                            if (
                                other is not z
                                and abs(other["x"]-z["x"]) < 90
                            ):
                                other["health"] -= damage*.3
                                other["flash"] = .1

                    if b["kind"] in ("ice", "slow"):
                        z["speed"] = min(z["speed"], 7)

                    if any(
                        p["name"] == "Torchwood"
                        and p["row"] == b["row"]
                        and p["x"] < b["x"] < p["x"]+90
                        for p in self.plants
                    ):
                        damage *= 2

                    self.damage_zombie(z, damage)

                    self.burst(
                        b["x"], b["y"],
                        (120, 240, 100), 5
                    )

                    hit = True
                    break

            if self.boss and not hit:
                if (
                    abs(self.boss["x"]-b["x"]) < 45
                    and abs(self.boss["y"]-b["y"]) < 65
                ):
                    self.boss["health"] -= b["damage"]
                    self.boss["flash"] = .15
                    self.play("boss_hit")
                    hit = True

            if hit and b in self.bullets:
                self.bullets.remove(b)

        # Zombiler
        for z in self.zombies[:]:
            z["anim"] += dt
            z["flash"] = max(0, z["flash"]-dt)
            z["knockback"] = max(
                0,
                z["knockback"]-dt*20
            )

            if z["health"] <= 0:
                self.zombies.remove(z)
                self.score += 10
                self.level_kills += 1

                self.burst(
                    z["x"], z["y"],
                    (100, 180, 90), 14
                )
                continue

            target = None

            for p in self.plants:
                if (
                    p["row"] == z["row"]
                    and abs(z["x"]-p["x"]) < 29
                ):
                    target = p
                    break

            if target:
                z["attack"] += dt

                if z["attack"] >= .7:
                    target["health"] -= 35
                    target["hit"] = .2
                    z["attack"] = 0

                    self.play("hit")

                    self.particle(
                        target["x"],
                        target["y"],
                        (180, 150, 100),
                        4
                    )

                if target["health"] <= 0:
                    self.burst(
                        target["x"],
                        target["y"],
                        (100, 150, 60),
                        8
                    )

                    if target in self.plants:
                        self.plants.remove(target)

            else:
                z["x"] -= z["speed"]*dt

            if z["x"] < 95:
                self.state = "over"
                self.play("lose")
                return

        # Patron
        if self.boss:
            b = self.boss

            b["anim"] += dt
            b["flash"] = max(0, b["flash"]-dt)
            b["attack"] += dt

            if b["attack"] > 2.5:
                b["attack"] = 0
                row = int((b["y"]-GY)//CH)

                for p in self.plants:
                    if (
                        p["row"] == row
                        and abs(p["x"]-b["x"]) < 200
                    ):
                        p["health"] -= 100
                        p["hit"] = .3

                        self.particle(
                            p["x"], p["y"],
                            (255, 80, 40), 10
                        )

            b["x"] -= b["speed"]*dt

            if b["health"] <= 0:
                self.burst(
                    b["x"], b["y"],
                    (255, 100, 35), 40
                )

                self.boss = None
                self.score += 500
                self.level_kills += self.level_goal

                self.play("explosion")

            elif b["x"] < 95:
                self.state = "over"
                self.play("lose")
                return

        # Ölü bitkiler
        for p in self.plants[:]:
            if p["health"] <= 0:
                self.plants.remove(p)

        # Parçacıklar
        for pp in self.particles[:]:
            pp["x"] += pp["vx"]*dt
            pp["y"] += pp["vy"]*dt
            pp["vy"] += 100*dt
            pp["life"] -= dt

            if pp["life"] <= 0:
                self.particles.remove(pp)

        # Bölüm bitişi
        if (
            self.level_kills >= self.level_goal
            and not self.zombies
            and self.boss is None
        ):
            self.unlocked_level = max(
                self.unlocked_level,
                min(20, self.current_level+1)
            )

            old_count = self.unlocked_plant_count

            self.unlocked_plant_count = max(
                self.unlocked_plant_count,
                min(
                    len(ALL_PLANTS),
                    self.current_level+5
                )
            )

            if self.unlocked_plant_count > old_count:
                self.newly_unlocked_plant = ALL_PLANTS[old_count]
            else:
                self.newly_unlocked_plant = None

            self.state = "complete"
            self.play("win")

    # =================================================
    # KARTLAR VE OYUN EKRANI
    # =================================================

    def draw_card(self, name, x, y, active=False):
        self.rect(
            x, y, 82, 73,
            (45, 100, 40) if active else (100, 65, 35),
            8,
            (255, 210, 65)
        )

        self.draw_plant_icon(name, x+41, y+29)

        self.rect(
            x+5, y+51,
            72, 18,
            (245, 225, 175), 5
        )

        self.text(
            PLANTS[name][0],
            x+41, y+60,
            13,
            (20, 25, 20)
        )

    def draw_game(self):
        self.draw_cached_background()

        self.rect(
            5, 5, 950, 88,
            (55, 35, 20), 14,
            (210, 150, 70)
        )

        self.rect(
            15, 15, 105, 65,
            (255, 215, 100), 10
        )

        self.text("GÜNEŞ", 67, 28, 15, (20, 25, 20))
        self.text(self.sun, 67, 58, 25, (20, 25, 20))

        for i, name in enumerate(self.deck):
            self.draw_card(
                name,
                125+i*88,
                12,
                self.selected == name
            )

        self.rect(
            780, 17, 165, 58,
            (55, 95, 50), 10
        )

        self.text(
            "BÖLÜM "+str(self.current_level)+"/20",
            862, 35, 17,
            (255, 210, 65)
        )

        self.text(
            "ÖLDÜRÜLEN "+str(self.level_kills)+"/"+str(self.level_goal),
            862, 61, 12
        )

        if self.selected:
            self.rect(
                365, 96, 230, 20,
                (40, 75, 35), 7
            )

            self.text(
                "SEÇİLDİ: "+TRANSLATIONS[self.selected],
                480, 106, 12,
                (255, 210, 65)
            )

        for p in self.plants:
            self.draw_plant(p)

        bullet_colors = {
            "ice": (100, 210, 255),
            "slow": (100, 210, 255),
            "fire": (255, 110, 30),
            "electric": (190, 100, 255),
            "laser": (255, 80, 180),
            "melon": (80, 190, 70),
            "lob": (120, 190, 65),
            "mushroom": (180, 90, 210)
        }

        for b in self.bullets:
            col = bullet_colors.get(
                b["kind"],
                (100, 230, 65)
            )

            for tx, ty in b["trail"]:
                self.circle(tx, ty, 4, col)

            self.glow(b["x"], b["y"], 9, col)
            self.circle(b["x"], b["y"], 8, col)
            self.circle(
                b["x"]-3,
                b["y"]-3,
                3,
                (255, 255, 255)
            )

        for z in self.zombies:
            self.draw_zombie(z)

        self.draw_boss()

        for s in self.suns:
            self.draw_sun(s)

        for p in self.particles:
            alpha = max(0, p["life"]/p["max"])

            self.circle(
                p["x"],
                p["y"],
                max(1, p["size"]*alpha),
                p["color"]
            )

        self.button(
            "DURAKLAT",
            880, 495,
            65, 35,
            (70, 55, 35)
        )

        if self.boss:
            self.rect(
                300, 95,
                360, 12,
                (65, 20, 20), 5
            )

            self.rect(
                300, 95,
                360*max(
                    0,
                    self.boss["health"]/self.boss["max"]
                ),
                12,
                (230, 45, 45), 5
            )

            self.text(
                "PATRON",
                480, 82,
                12,
                (255, 110, 90)
            )

    # =================================================
    # MENÜ
    # =================================================

    def draw_menu(self):
        self.draw_cached_background()

        self.rect(0, 0, W, H, (10, 25, 15))

        self.rect(
            180, 35, 600, 465,
            (90, 55, 25), 25,
            (255, 210, 65)
        )

        self.text(
            "BİTKİ",
            480, 85, 55,
            (110, 220, 65)
        )

        self.text(
            "SAVUNMASI",
            480, 140, 55,
            (255, 210, 65)
        )

        self.draw_plant_icon("Sunflower", 300, 250)
        self.draw_plant_icon("Peashooter", 650, 250)

        for label, y in [
            ("OYNA", 300),
            ("BÖLÜM SEÇ", 355),
            ("BİTKİ DESTESİ", 410),
            ("AYARLAR", 465)
        ]:
            self.button(label, 335, y, 290, 42)

    # =================================================
    # BÖLÜM SEÇME
    # =================================================

    def draw_levels(self):
        self.draw_cached_background()

        self.rect(
            25, 15, 910, 510,
            (65, 45, 25), 18,
            (255, 210, 65)
        )

        self.text(
            "BÖLÜM SEÇ",
            480, 45, 32,
            (255, 210, 65)
        )

        for i in range(20):
            col = i%5
            row = i//5

            x = 100+col*155
            y = 105+row*88

            opened = i+1 <= self.unlocked_level

            self.rect(
                x, y, 115, 62,
                (55, 135, 50) if opened else (65, 65, 65),
                10,
                (255, 210, 65)
            )

            self.text(
                "BÖLÜM "+str(i+1),
                x+57, y+22, 15
            )

            label = (
                "PATRON"
                if (i+1)%5 == 0
                else "AÇIK" if opened
                else "KİLİTLİ"
            )

            self.text(
                label,
                x+57, y+44,
                11,
                (255, 210, 65)
            )

        self.button("GERİ", 350, 475, 260, 42)

    # =================================================
    # BİTKİ DESTESİ
    # =================================================

    def draw_deck(self):
        self.draw_cached_background()

        self.rect(
            15, 12, 930, 515,
            (80, 50, 25), 18,
            (255, 210, 65)
        )

        self.text(
            "BİTKİ KOLEKSİYONU",
            480, 35, 29,
            (255, 210, 65)
        )

        self.text("EN FAZLA 5 BİTKİ SEÇ", 285, 83, 16)
        self.text("DESTEN", 760, 83, 17, (255, 210, 65))

        page = ALL_PLANTS[
            self.deck_page*10:
            (self.deck_page+1)*10
        ]

        for i, name in enumerate(page):
            col = i%5
            row = i//5

            x = 35+col*112
            y = 115+row*145

            unlocked = self.is_plant_unlocked(name)
            active = name in self.deck

            self.draw_card(name, x, y, active)

            if not unlocked:
                self.rect(
                    x, y, 82, 73,
                    (25, 25, 25), 5
                )

                self.text(
                    "KİLİTLİ",
                    x+41, y+34,
                    12,
                    (255, 110, 90)
                )

                self.text(
                    "BÖLÜM "+str(ALL_PLANTS.index(name)-4),
                    x+41, y+88,
                    10,
                    (255, 210, 65)
                )

            else:
                self.text(
                    TRANSLATIONS[name],
                    x+41, y+88,
                    10,
                    (255, 210, 65)
                )

                if active:
                    self.text(
                        "SEÇİLDİ",
                        x+41, y+105,
                        9,
                        (130, 255, 130)
                    )
                else:
                    self.text(
                        "EKLEMEK İÇİN DOKUN",
                        x+41, y+105,
                        8
                    )

        self.rect(
            620, 105, 290, 350,
            (55, 85, 45), 14,
            (200, 160, 85)
        )

        for i, name in enumerate(self.deck):
            x = 660
            y = 120+i*65

            self.draw_card(name, x, y, True)

            self.text(
                TRANSLATIONS[name],
                x+125, y+35,
                13,
                (255, 210, 65)
            )

        self.text(
            str(len(self.deck))+"/5 SEÇİLDİ",
            765, 450, 17,
            (255, 210, 65)
        )

        self.button("ÖNCEKİ", 45, 450, 125, 40)
        self.button("SONRAKİ", 185, 450, 125, 40)

        self.text(
            "SAYFA "+str(self.deck_page+1)+" / 2",
            390, 470, 15,
            (255, 210, 65)
        )

        self.button(
            "ANA MENÜYE DÖN",
            650, 470, 250, 40
        )

    # =================================================
    # AYARLAR
    # =================================================

    def draw_settings(self):
        self.draw_cached_background()

        self.rect(
            200, 80, 560, 380,
            (75, 50, 25), 20,
            (255, 210, 65)
        )

        self.text(
            "AYARLAR",
            480, 130, 38,
            (255, 210, 65)
        )

        self.text("SES", 480, 230, 25)

        self.text(
            "AÇIK" if self.sound_on else "KAPALI",
            480, 275, 25,
            (255, 210, 65)
        )

        self.button("GERİ", 350, 365, 260, 50)

    # =================================================
    # OYUN BİTTİ
    # =================================================

    def draw_over(self):
        self.draw_cached_background()

        self.rect(0, 0, W, H, (10, 10, 10))

        self.rect(
            230, 140, 500, 260,
            (85, 50, 30), 20,
            (255, 210, 65)
        )

        self.text(
            "OYUN BİTTİ",
            480, 190, 45,
            (255, 90, 60)
        )

        self.text(
            "BÖLÜM "+str(self.current_level)+"  PUAN: "+str(self.score),
            480, 255, 23,
            (255, 210, 65)
        )

        self.button("TEKRAR DENE", 350, 315, 260, 48)
        self.button("BÖLÜM SEÇ", 350, 370, 260, 40)

    # =================================================
    # BÖLÜM TAMAMLANDI
    # =================================================

    def draw_complete(self):
        self.draw_cached_background()

        self.rect(0, 0, W, H, (10, 10, 10))

        self.rect(
            210, 90, 540, 360,
            (75, 55, 25), 20,
            (255, 210, 65)
        )

        self.text(
            "BÖLÜM TAMAMLANDI!",
            480, 140, 40,
            (130, 240, 90)
        )

        self.text(
            "BÖLÜM "+str(self.current_level)+" TAMAMLANDI",
            480, 195, 21,
            (255, 210, 65)
        )

        if self.newly_unlocked_plant:
            self.text(
                "YENİ BİTKİ AÇILDI!",
                480, 245, 21,
                (130, 255, 100)
            )

            self.draw_plant_icon(
                self.newly_unlocked_plant,
                480, 310
            )

            self.text(
                TRANSLATIONS[self.newly_unlocked_plant],
                480, 365, 18,
                (255, 210, 65)
            )

        elif self.current_level >= 20:
            self.text(
                "20 BÖLÜMÜ DE BİTİRDİN!",
                480, 290, 21,
                (255, 210, 65)
            )

        else:
            self.text(
                "TÜM BİTKİLER AÇILDI!",
                480, 290, 20,
                (255, 210, 65)
            )

        self.button(
            "SONRAKİ BÖLÜM"
            if self.current_level < 20
            else "BÖLÜM SEÇ",
            350, 385, 260, 42
        )

    # =================================================
    # DURAKLATMA MENÜSÜ
    # =================================================

    def draw_pause(self):
        self.draw_game()

        self.rect(
            300, 145, 360, 250,
            (45, 45, 35), 20,
            (255, 210, 65)
        )

        self.text(
            "DURAKLATILDI",
            480, 195, 32,
            (255, 210, 65)
        )

        self.button(
            "DEVAM ET",
            350, 245, 260, 48
        )

        self.button(
            "ANA MENÜ",
            350, 315, 260, 48,
            (120, 65, 40)
        )

    # =================================================
    # ÇİZİM DÖNGÜSÜ
    # =================================================

    def redraw(self, *args):
        self.canvas.clear()

        if self.width <= 0 or self.height <= 0:
            return

        self.scale = min(
            self.width/W,
            self.height/H
        )

        self.off_x = (
            self.width-W*self.scale
        )/2

        self.off_y = (
            self.height-H*self.scale
        )/2

        with self.canvas:
            PushMatrix()

            Translate(
                self.x+self.off_x,
                self.y+self.off_y
            )

            Scale(
                self.scale,
                self.scale,
                1
            )

            if self.state == "game":
                self.draw_game()

            elif self.state == "menu":
                self.draw_menu()

            elif self.state == "levels":
                self.draw_levels()

            elif self.state == "deck":
                self.draw_deck()

            elif self.state == "settings":
                self.draw_settings()

            elif self.state == "over":
                self.draw_over()

            elif self.state == "complete":
                self.draw_complete()

            elif self.state == "paused":
                self.draw_pause()

            PopMatrix()

    # =================================================
    # GÜNCELLEME
    # =================================================

    def update(self, dt):
        if self.state == "game":
            self.update_game(min(dt, .035))
            self.redraw()

        # Menü ve diğer sabit ekranlar artık her karede
        # gereksiz yere yeniden çizilmiyor.

    # =================================================
    # DOKUNMATİK KOORDİNATLARI
    # =================================================

    def touch_position(self, touch):
        lx, ly = self.to_widget(
            touch.x,
            touch.y
        )

        x = (
            lx-self.off_x
        )/max(self.scale, .001)

        y = H-(
            (ly-self.off_y)/max(self.scale, .001)
        )

        return x, y

    def on_touch_down(self, touch):
        mx, my = self.touch_position(touch)

        if not (
            0 <= mx <= W
            and 0 <= my <= H
        ):
            return True

        self.handle_click(mx, my)
        self.redraw()

        return True

    # =================================================
    # OYUN İÇİ DOKUNMATİK
    # =================================================

    def game_click(self, mx, my):
        if my < 90:
            for i, name in enumerate(self.deck):
                x = 125+i*88

                if x <= mx <= x+82:
                    self.selected = name
                    self.play("click")
                    return

        for s in self.suns[:]:
            if math.hypot(
                mx-s["x"],
                my-s["y"]
            ) < 30:
                self.suns.remove(s)
                self.sun += 50

                self.particle(
                    s["x"],
                    s["y"],
                    (255, 220, 70),
                    10
                )

                self.play("sun")
                return

        if mx > 870 and my > 490:
            self.paused_from = "game"
            self.state = "paused"
            self.play("click")
            return

        self.place_plant(mx, my)

    # =================================================
    # TÜM MENÜ KONTROLLERİ
    # =================================================

    def handle_click(self, mx, my):
        if self.state == "menu":
            if 335 <= mx <= 625:
                if 300 <= my <= 342:
                    self.reset_game(self.unlocked_level)

                elif 355 <= my <= 397:
                    self.state = "levels"

                elif 410 <= my <= 452:
                    self.deck_page = 0
                    self.state = "deck"

                elif 465 <= my <= 507:
                    self.state = "settings"

        elif self.state == "levels":
            if (
                350 <= mx <= 610
                and 475 <= my <= 520
            ):
                self.state = "menu"
                return

            for i in range(20):
                col = i%5
                row = i//5

                x = 100+col*155
                y = 105+row*88

                if (
                    x <= mx <= x+115
                    and y <= my <= y+62
                    and i+1 <= self.unlocked_level
                ):
                    self.reset_game(i+1)
                    return

        elif self.state == "deck":
            if (
                650 <= mx <= 900
                and 470 <= my <= 510
            ):
                self.state = "menu"
                return

            if (
                45 <= mx <= 170
                and 450 <= my <= 490
            ):
                self.deck_page = max(
                    0,
                    self.deck_page-1
                )
                return

            if (
                185 <= mx <= 310
                and 450 <= my <= 490
            ):
                self.deck_page = min(
                    1,
                    self.deck_page+1
                )
                return

            page = ALL_PLANTS[
                self.deck_page*10:
                (self.deck_page+1)*10
            ]

            for i, name in enumerate(page):
                col = i%5
                row = i//5

                x = 35+col*112
                y = 115+row*145

                if (
                    x <= mx <= x+82
                    and y <= my <= y+73
                ):
                    if not self.is_plant_unlocked(name):
                        self.play("click")
                        return

                    if name in self.deck:
                        if len(self.deck) > 1:
                            self.deck.remove(name)

                    elif len(self.deck) < MAX_DECK:
                        self.deck.append(name)

                    self.play("click")
                    return

        elif self.state == "settings":
            if (
                350 <= mx <= 610
                and 340 <= my <= 420
            ):
                self.state = "menu"

            elif (
                380 <= mx <= 580
                and 240 <= my <= 310
            ):
                self.sound_on = not self.sound_on

                if self.music:
                    self.music.volume = (
                        .28 if self.sound_on else 0
                    )

        elif self.state == "game":
            self.game_click(mx, my)

        elif self.state == "paused":
            if (
                350 <= mx <= 610
                and 245 <= my <= 293
            ):
                self.state = "game"
                self.play("click")

            elif (
                350 <= mx <= 610
                and 315 <= my <= 363
            ):
                self.state = "menu"
                self.selected = None
                self.play("click")

        elif self.state == "over":
            if (
                350 <= mx <= 610
                and 315 <= my <= 363
            ):
                self.reset_game(self.current_level)

            elif (
                350 <= mx <= 610
                and 370 <= my <= 415
            ):
                self.state = "levels"

        elif self.state == "complete":
            if (
                350 <= mx <= 610
                and 385 <= my <= 427
            ):
                if self.current_level < 20:
                    self.reset_game(
                        self.current_level+1
                    )
                    self.newly_unlocked_plant = None

                else:
                    self.state = "levels"


# =====================================================
# UYGULAMA
# =====================================================

class PlantDefenseApp(App):

    def build(self):
        self.title = "Bitki Savunması"

        game = PlantDefense()

        Clock.schedule_once(
            lambda dt: game.force_landscape(),
            .5
        )

        return game

    def on_pause(self):
        return True


if __name__ == "__main__":
    PlantDefenseApp().run()
