[app]

title = Bitki Savunmasi
package.name = bitkisavunmasi
package.domain = org.tomartomar

source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,atlas,wav
version = 1.0

requirements = python3,kivy

orientation = landscape
fullscreen = 1

android.archs = arm64-v8a
android.minapi = 23
android.accept_sdk_license = True

[buildozer]

log_level = 2
warn_on_root = 1
