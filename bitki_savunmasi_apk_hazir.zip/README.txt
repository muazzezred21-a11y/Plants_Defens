BITKI SAVUNMASI - ANDROID APK

Bu klasorde:
- main.py: Kivy oyun kodu
- buildozer.spec: Android paket ayarlari
- .github/workflows/build-apk.yml: GitHub Actions ile bulutta APK derleme

TELEFONDAN APK OLUSTURMA:
1. GitHub'da yeni bir PUBLIC repository olustur.
2. Bu ZIP'in icindeki dosyalari ve .github klasorunu repository ana dizinine yukle.
3. Repository'de Actions sekmesine gir.
4. "Bitki Savunmasi APK" workflow'unu secip Run workflow'a dokun.
5. Islem bitince tamamlanan workflow calismasini ac.
6. Artifacts bolumundeki bitki-savunmasi-apk dosyasini indirip ZIP'ten APK'yi cikar.

Not: Derleme GitHub'in bulut bilgisayarinda yapilir. Ilk derleme uzun surebilir.
